<?php
printf("<!DOCTYPE html>\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>Football</title>\n");
printf("<meta charset=\"utf-8\"/>\n");
printf("<link rel=\"stylesheet\" href=\"foot.css\"/>\n");
printf("</head>\n");
printf("<body>\n");
printf("<h1>Liste des équipes</h1>\n");
printf("</body>\n");
printf("</html>\n");
?>
